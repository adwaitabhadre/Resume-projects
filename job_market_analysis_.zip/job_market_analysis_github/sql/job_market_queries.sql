-- Job Market Analytics Dashboard SQL Queries
-- Author: Adwaita Bhadre

-- Table name used in these examples:
-- cleaned_job_postings

-- 1. Total number of job records
SELECT
    COUNT(*) AS total_jobs
FROM cleaned_job_postings;

-- 2. Top hiring locations
SELECT
    location_clean,
    COUNT(*) AS total_jobs
FROM cleaned_job_postings
WHERE location_clean IS NOT NULL
GROUP BY location_clean
ORDER BY total_jobs DESC
LIMIT 10;

-- 3. Experience-level distribution
SELECT
    experience_level,
    COUNT(*) AS total_jobs
FROM cleaned_job_postings
GROUP BY experience_level
ORDER BY total_jobs DESC;

-- 4. Average salary by experience level
SELECT
    experience_level,
    ROUND(AVG(salary_estimate), 2) AS average_salary
FROM cleaned_job_postings
WHERE salary_estimate IS NOT NULL
GROUP BY experience_level
ORDER BY average_salary DESC;

-- 5. Top analyst job titles
SELECT
    job_title_clean,
    COUNT(*) AS total_jobs
FROM cleaned_job_postings
WHERE LOWER(job_title_clean) LIKE '%analyst%'
GROUP BY job_title_clean
ORDER BY total_jobs DESC
LIMIT 15;

-- 6. Jobs requiring SQL
SELECT
    COUNT(*) AS sql_jobs
FROM cleaned_job_postings
WHERE LOWER(skills_text) LIKE '%sql%';

-- 7. Jobs requiring Power BI
SELECT
    COUNT(*) AS power_bi_jobs
FROM cleaned_job_postings
WHERE LOWER(skills_text) LIKE '%power bi%';

-- 8. Jobs requiring Python
SELECT
    COUNT(*) AS python_jobs
FROM cleaned_job_postings
WHERE LOWER(skills_text) LIKE '%python%';

-- 9. Role-wise average salary
SELECT
    job_title_clean,
    COUNT(*) AS total_jobs,
    ROUND(AVG(salary_estimate), 2) AS average_salary
FROM cleaned_job_postings
WHERE salary_estimate IS NOT NULL
GROUP BY job_title_clean
HAVING COUNT(*) >= 10
ORDER BY average_salary DESC
LIMIT 20;

-- 10. Location-wise salary trend
SELECT
    location_clean,
    COUNT(*) AS total_jobs,
    ROUND(AVG(salary_estimate), 2) AS average_salary
FROM cleaned_job_postings
WHERE salary_estimate IS NOT NULL
GROUP BY location_clean
HAVING COUNT(*) >= 10
ORDER BY average_salary DESC
LIMIT 15;
