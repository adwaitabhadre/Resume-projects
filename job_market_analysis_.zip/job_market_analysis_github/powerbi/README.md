# Power BI Dashboard

This folder is for the Power BI dashboard file.

Recommended file name:

```text
Job_Market_Analytics_Dashboard.pbix
```

## Dashboard Pages

1. Job Market Overview
2. Skill Demand Analysis
3. Salary Trend Analysis
4. Location & Experience Analysis

## Suggested Power BI Visuals

- KPI cards: total jobs, top skill, top location, average salary
- Bar chart: top in-demand skills
- Column chart: jobs by location
- Salary distribution chart
- Experience-level breakdown
- Role-wise skill comparison
- Slicers for role, location, experience level, and skill

## Sample DAX Measures

```DAX
Total Jobs = COUNTROWS('cleaned_job_postings')

Average Salary = AVERAGE('cleaned_job_postings'[salary_estimate])

Jobs with SQL =
CALCULATE(
    COUNTROWS('cleaned_job_postings'),
    CONTAINSSTRING('cleaned_job_postings'[skills_text], "sql")
)

Jobs with Power BI =
CALCULATE(
    COUNTROWS('cleaned_job_postings'),
    CONTAINSSTRING('cleaned_job_postings'[skills_text], "power bi")
)
```
