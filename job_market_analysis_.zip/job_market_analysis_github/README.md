# Job Market Analytics Dashboard

## Project Overview

This is an end-to-end data analytics project built using a Kaggle dataset containing **54,000+ job records**. The project focuses on analyzing hiring patterns, salary trends, skill demand, and experience-level requirements across analyst-related job roles.

The final output is a **4-page interactive Power BI dashboard** supported by SQL analysis, Power Query transformations, DAX measures, and Python-based exploratory analysis.

## Objective

The goal of this project was to transform raw job-market data into clear insights that can help job seekers, recruiters, and business teams understand current hiring trends.

Main questions explored:

- Which skills are most in demand for analyst roles?
- How do salary trends vary by role, location, and experience level?
- Which locations have stronger hiring demand?
- What tools are commonly required for Data Analyst and Business Analyst roles?
- How can dashboarding help summarize job-market trends for decision-making?

## Dataset

- **Source:** Kaggle
- **Size:** 54,000+ job records
- **Domain:** Job market analytics / recruitment analytics
- **Main fields:** job title, company, location, salary, experience, skills, job description, and posting details

> Note: The raw Kaggle dataset is not included in this repository due to size/licensing. Add your dataset manually inside the `data/` folder and rename it as `job_postings.csv`.

## Tools & Technologies

- **Power BI**
- **SQL**
- **Power Query**
- **DAX**
- **Python**
- **Pandas**
- **NumPy**
- **Matplotlib**
- **Seaborn**
- **Excel**

## Project Workflow

### 1. Data Collection

The job postings dataset was sourced from Kaggle and reviewed to understand available columns, missing values, and possible analysis areas.

### 2. Data Cleaning & Transformation

Data cleaning was performed using Python and Power Query.

Key steps:

- Removed duplicate job records
- Handled missing values
- Standardized job titles and locations
- Cleaned salary-related fields
- Created experience-level categories
- Extracted important technical skills from job descriptions
- Prepared dashboard-ready tables for Power BI

### 3. SQL Analysis

SQL was used to analyze:

- Top in-demand skills
- Job count by location
- Role-wise hiring trends
- Salary patterns by role
- Experience-level distribution
- Analyst role segmentation

### 4. Power BI Dashboard Development

A 4-page interactive dashboard was designed in Power BI.

Dashboard pages:

1. **Job Market Overview**
2. **Skill Demand Analysis**
3. **Salary Trend Analysis**
4. **Location & Experience Analysis**

Dashboard features:

- KPI cards
- Drill-down filters
- Role-wise slicers
- Location-wise analysis
- Skill demand visuals
- Salary trend charts
- Experience-level breakdown

## Key Insights

- SQL, Excel, and Power BI were identified as top in-demand skills for analyst roles.
- Python appeared more frequently in data analyst and data science-oriented roles.
- Salary trends varied based on experience level, role type, and location.
- Entry-level roles commonly focused on Excel, SQL, reporting, and dashboarding.
- Advanced roles showed higher demand for Python, analytics automation, machine learning, and data engineering exposure.

## Business Value

This project can help:

- Job seekers identify high-value skills to learn.
- Recruiters understand market demand for analyst roles.
- Training institutes design job-market-focused programs.
- Hiring teams benchmark role expectations and skill requirements.

## Repository Structure

```text
job-market-analytics-dashboard/
│
├── data/
│   └── README.md
│
├── notebooks/
│   └── job_market_analysis.ipynb
│
├── sql/
│   └── job_market_queries.sql
│
├── powerbi/
│   └── README.md
│
├── assets/
│   └── portfolio_page.html
│
├── job_market_analysis.py
├── requirements.txt
└── README.md
```

## How to Run This Project

1. Clone this repository.

```bash
git clone https://github.com/your-username/job-market-analytics-dashboard.git
cd job-market-analytics-dashboard
```

2. Install the required Python libraries.

```bash
pip install -r requirements.txt
```

3. Add the Kaggle dataset inside the `data/` folder and rename it:

```text
data/job_postings.csv
```

4. Run the Python analysis script.

```bash
python job_market_analysis.py
```

5. Use the cleaned output file in Power BI:

```text
data/cleaned_job_postings.csv
```

## Portfolio Summary

This project demonstrates my ability to clean and transform a large dataset, perform exploratory data analysis, write SQL queries, build dashboard-ready datasets, create DAX measures, and present insights through an interactive Power BI dashboard.

## Author

**Adwaita Bhadre**  
Data Analyst | SQL | Python | Power BI | Excel  
LinkedIn: https://www.linkedin.com/in/adwaita-bhadre-610328232  
GitHub: https://github.com/adwaita
