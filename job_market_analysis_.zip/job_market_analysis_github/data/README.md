# Data Folder

Place the Kaggle job postings dataset in this folder.

Expected file name:

```text
job_postings.csv
```

The raw dataset is not included in this repository due to file size and licensing restrictions.

After running the Python script, the cleaned file will be generated as:

```text
cleaned_job_postings.csv
```

Suggested fields in the dataset:

- job_title
- company
- location
- salary
- experience
- skills
- job_description
- posted_date
