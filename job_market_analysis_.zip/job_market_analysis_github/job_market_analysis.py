"""
Job Market Analytics Dashboard
Author: Adwaita Bhadre

This script performs data cleaning and exploratory analysis on a Kaggle job postings dataset.
Expected raw file path: data/job_postings.csv
Output file path: data/cleaned_job_postings.csv
"""

from pathlib import Path
import re
from typing import Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


DATA_PATH = Path("data/job_postings.csv")
OUTPUT_PATH = Path("data/cleaned_job_postings.csv")
ASSETS_DIR = Path("assets")
ASSETS_DIR.mkdir(exist_ok=True)


def clean_column_names(df: pd.DataFrame) -> pd.DataFrame:
    """Standardize column names for easier analysis."""
    df = df.copy()
    df.columns = (
        df.columns
        .str.strip()
        .str.lower()
        .str.replace(" ", "_", regex=False)
        .str.replace("-", "_", regex=False)
    )
    return df


def find_column(df: pd.DataFrame, possible_names: list[str]) -> Optional[str]:
    """Find the first matching column from possible column names."""
    for col in possible_names:
        if col in df.columns:
            return col
    return None


def categorize_experience(value: object) -> str:
    """Convert raw experience values into broad categories."""
    if pd.isna(value):
        return "Not Specified"

    text = str(value).lower()
    numbers = re.findall(r"\d+", text)
    years = [int(n) for n in numbers] if numbers else []

    if any(word in text for word in ["fresher", "entry", "graduate", "0 year", "0-1"]):
        return "Entry Level"

    if years:
        min_year = min(years)
        if min_year <= 1:
            return "Entry Level"
        if min_year <= 3:
            return "Junior"
        if min_year <= 6:
            return "Mid Level"
        return "Senior"

    return "Not Specified"


def extract_salary_number(value: object) -> float:
    """Extract a rough salary estimate from text values."""
    if pd.isna(value):
        return np.nan

    text = str(value).lower().replace(",", "")
    numbers = re.findall(r"\d+\.?\d*", text)

    if not numbers:
        return np.nan

    nums = [float(n) for n in numbers]
    avg_value = sum(nums) / len(nums)

    if any(unit in text for unit in ["lpa", "lac", "lakh"]):
        return avg_value * 100000

    if "k" in text:
        return avg_value * 1000

    return avg_value


def extract_skills(text: object) -> list[str]:
    """Extract common analytics skills from job descriptions or skill fields."""
    if pd.isna(text):
        return []

    skill_keywords = [
        "sql", "excel", "python", "power bi", "tableau", "r", "pandas",
        "numpy", "spark", "aws", "azure", "machine learning", "statistics",
        "data visualization", "dashboard", "etl", "mysql", "postgresql",
        "snowflake", "databricks", "power query", "dax", "jira", "github"
    ]

    lower_text = str(text).lower()
    return [skill for skill in skill_keywords if skill in lower_text]


def prepare_dataset(df: pd.DataFrame) -> pd.DataFrame:
    """Clean and enrich the raw job postings dataset."""
    df = clean_column_names(df)
    df = df.drop_duplicates().copy()

    title_col = find_column(df, ["job_title", "title", "role", "position"])
    company_col = find_column(df, ["company", "company_name", "employer"])
    location_col = find_column(df, ["location", "city", "job_location"])
    salary_col = find_column(df, ["salary", "salary_range", "pay", "compensation"])
    experience_col = find_column(df, ["experience", "experience_required", "exp"])
    skills_col = find_column(df, ["skills", "required_skills", "key_skills"])
    description_col = find_column(df, ["job_description", "description", "details"])

    if title_col:
        df["job_title_clean"] = df[title_col].astype(str).str.strip().str.title()

    if company_col:
        df["company_clean"] = df[company_col].astype(str).str.strip().str.title()

    if location_col:
        df["location_clean"] = df[location_col].astype(str).str.strip().str.title()

    if salary_col:
        df["salary_estimate"] = df[salary_col].apply(extract_salary_number)

    if experience_col:
        df["experience_level"] = df[experience_col].apply(categorize_experience)
    else:
        df["experience_level"] = "Not Specified"

    if skills_col:
        text_series = df[skills_col].fillna("").astype(str)
    elif description_col:
        text_series = df[description_col].fillna("").astype(str)
    else:
        text_series = pd.Series([""] * len(df), index=df.index)

    df["extracted_skills"] = text_series.apply(extract_skills)
    df["skills_text"] = df["extracted_skills"].apply(lambda skills: ", ".join(skills))
    df["skill_count"] = df["extracted_skills"].apply(len)

    return df


def create_visualizations(df: pd.DataFrame) -> None:
    """Create basic EDA visualizations and save them in assets folder."""
    if "extracted_skills" in df.columns:
        skill_series = df["extracted_skills"].explode().dropna()

        if not skill_series.empty:
            plt.figure(figsize=(10, 6))
            skill_series.value_counts().head(10).sort_values().plot(kind="barh")
            plt.title("Top 10 In-Demand Skills")
            plt.xlabel("Number of Mentions")
            plt.ylabel("Skill")
            plt.tight_layout()
            plt.savefig(ASSETS_DIR / "top_skills.png")
            plt.close()

    if "location_clean" in df.columns:
        top_locations = df["location_clean"].value_counts().head(10)

        if not top_locations.empty:
            plt.figure(figsize=(10, 6))
            top_locations.sort_values().plot(kind="barh")
            plt.title("Top 10 Hiring Locations")
            plt.xlabel("Number of Job Postings")
            plt.ylabel("Location")
            plt.tight_layout()
            plt.savefig(ASSETS_DIR / "top_locations.png")
            plt.close()

    if "salary_estimate" in df.columns:
        salary_data = df["salary_estimate"].dropna()

        if not salary_data.empty:
            plt.figure(figsize=(10, 6))
            sns.histplot(salary_data, bins=30)
            plt.title("Salary Estimate Distribution")
            plt.xlabel("Salary Estimate")
            plt.ylabel("Number of Jobs")
            plt.tight_layout()
            plt.savefig(ASSETS_DIR / "salary_distribution.png")
            plt.close()


def print_summary(df: pd.DataFrame) -> None:
    """Print a short analysis summary."""
    print("Dataset shape after cleaning:", df.shape)

    if "job_title_clean" in df.columns:
        print("\nTop job titles:")
        print(df["job_title_clean"].value_counts().head(10))

    if "location_clean" in df.columns:
        print("\nTop hiring locations:")
        print(df["location_clean"].value_counts().head(10))

    if "experience_level" in df.columns:
        print("\nExperience level distribution:")
        print(df["experience_level"].value_counts())

    if "extracted_skills" in df.columns:
        print("\nTop in-demand skills:")
        print(df["extracted_skills"].explode().value_counts().head(15))


def main() -> None:
    if not DATA_PATH.exists():
        print(f"Dataset not found: {DATA_PATH}")
        print("Please add the Kaggle dataset as data/job_postings.csv")
        return

    raw_df = pd.read_csv(DATA_PATH)
    cleaned_df = prepare_dataset(raw_df)

    cleaned_df.to_csv(OUTPUT_PATH, index=False)
    create_visualizations(cleaned_df)
    print_summary(cleaned_df)

    print(f"\nCleaned dataset saved to: {OUTPUT_PATH}")
    print("Charts saved in assets folder.")


if __name__ == "__main__":
    main()
